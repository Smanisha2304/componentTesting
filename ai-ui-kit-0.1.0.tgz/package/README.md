# ai-ui-kit

Reusable **React component library for AI applications** built with **React, TypeScript, Chakra UI v3, and Framer Motion**.

This package provides ready-to-use UI components commonly needed in AI-powered applications such as chat interfaces, model configuration panels, logs tables, upload components, and more.

---

# ✨ Features

* ⚡ Built with **React + TypeScript**
* 🎨 **Chakra UI v3** based components
* 🧠 Components designed for **AI applications**
* 📦 Lightweight and tree-shakable
* 🧩 Fully typed components
* 🎬 Optional animations using **Framer Motion**

---

# 📦 Installation

Install the package along with required peer dependencies.

```bash
npm install ai-ui-kit
```

Required peer dependencies:

```bash
npm install react react-dom @chakra-ui/react @emotion/react @emotion/styled framer-motion
```

---

# ⚙️ Setup

Since this library uses **Chakra UI v3**, your application must wrap the app with `ChakraProvider`.

Example (`main.tsx` or `main.jsx`):

```tsx
import React from "react"
import ReactDOM from "react-dom/client"
import { ChakraProvider, defaultSystem } from "@chakra-ui/react"
import App from "./App"

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ChakraProvider value={defaultSystem}>
      <App />
    </ChakraProvider>
  </React.StrictMode>
)
```

---

# 🚀 Usage

Example using the **ChatHistory** component.

```tsx
import { ChatHistory } from "ai-ui-kit"

function App() {
  return (
    <ChatHistory
      messages={[
        { id: "1", role: "user", content: "Hello AI" },
        { id: "2", role: "assistant", content: "Hi there 👋" }
      ]}
    />
  )
}

export default App
```

---

# 📚 Available Components

### Chat Components

* `ChatShell`
* `ChatHistory`
* `ChatMessage`
* `ChatInput`

Used to build AI chat interfaces.

---

### Form Components

* `ModelEditor`
* `PromptEditor`
* `ConfigTable`

Useful for configuring AI models and prompts.

---

### Data & Logs

* `LogsTable`
* `UsageCard`

For displaying request logs and usage metrics.

---

### Upload Components

* `Dropzone`
* `FileQueue`
* `UploadProgress`

Useful for file upload workflows in AI tools.

---

### UI States

* `Loader`
* `EmptyState`
* `ErrorState`
* `FeedbackWidget`

---

# 🧩 Example Chat UI

```tsx
import { Box } from "@chakra-ui/react"
import { ChatHistory } from "ai-ui-kit"

function App() {
  return (
    <Box maxW="500px" mx="auto" mt={10}>
      <ChatHistory
        messages={[
          { id: "1", role: "user", content: "Hello AI" },
          { id: "2", role: "assistant", content: "How can I help you today?" }
        ]}
      />
    </Box>
  )
}
```

---

# 🛠 Development

Clone the repository:

```bash
git clone https://github.com/yourusername/ai-ui-kit.git
```

Install dependencies:

```bash
npm install
```

Run development mode:

```bash
npm run dev
```

Build the library:

```bash
npm run build
```

---

# 📦 Testing the Package Locally

To test the package locally before publishing:

```bash
npm pack
```

Then install it inside another project:

```bash
npm install ../ai-ui-kit/ai-ui-kit-0.1.0.tgz
```

---

# 📄 License

MIT License

---

# 🤝 Contributing

Contributions are welcome. Feel free to open issues or submit pull requests.

---

# 🌟 Author

Created by **Ccube**
